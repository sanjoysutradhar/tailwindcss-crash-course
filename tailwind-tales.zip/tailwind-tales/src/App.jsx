

function App() {
  

  return (
    <>
      {/* <div className="text-3xl font-bold underline">
        <h1> Hello World!!</h1>
      </div>
      <div>
        <p className="text-red-500 text-3xl text-left">Tom</p>
        <p className="text-gray-400 text-lg text-center">Jerry</p>
        <p className="text-blue-900 text-xs text-right">Max</p>
      </div>
      <div className="bg-red-500 bg-opacity-50 min-w-40 min-h-60">Tailwind Css is great </div>
      <div className="bg-blue-200 w-1/2 h-32">Tailwind Css is awesome </div>
      <div className="bg-gray-900 text-white bg-opacity-50 m-4 p-8 ">Tailwind Css is fantastic </div>*/}
      {/* <div className="bg-[url('https://th.bing.com/th/id/R.80048c94faacac8b7ff6af18efa3d92a?rik=Ac82coHKVHLVyg&riu=http%3a%2f%2fwonderfulengineering.com%2fwp-content%2fuploads%2f2016%2f01%2fnature-wallpapers-8.jpg&ehk=GoUR7nA3jNm0gIdWFJoMVL1iu%2bJuWOU7Nu7KkgKZzeQ%3d&risl=&pid=ImgRaw&r=0')] bg-center bg-no-repeat bg-cover h-screen"></div> */}
      {/* <div className="bg-gradient-to-r from-blue-300 via-purple-500 to-pink-300"> We are learning gradient</div> */}
        {/* //flex */}
        {/* <div className="flex">
          <div className="flex-1 border-green-800 border">First Div 1</div>
          <div className="flex-2 border-pink-700 border">Second Div 2</div>
        </div>

        <div className="flex flex-col justify-center items-center">
          <div>first</div>
          <div>Second</div>
        </div>


        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2">Grid item 1</div>
          <div>Grid item 2</div>
        </div> */}
      <div
      className="bg-blue-300 sm:bg-red-300 md:bg-green-300
       lg:bg-yellow-300 xl:bg-purple-300"
      >
        we are testing responsiveness
      </div>

      <div className="bg-primary text-customColor-500 font-custom">I am testing custom color</div>
        
        <p className="bg-slate-500 mt-2 ml-1 tablet:flex">Spacing Testing</p>
    </>
  )
}

export default App
